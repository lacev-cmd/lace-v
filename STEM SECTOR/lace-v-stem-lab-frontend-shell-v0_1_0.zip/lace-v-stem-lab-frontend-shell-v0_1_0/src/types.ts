export type JobType =
  | 'robotics-readiness'
  | 'battery-transition'
  | 'code-release'
  | 'asset-integrity'
  | 'lab-evidence'
  | 'technical-procurement';

export type GuideType =
  | 'guide-stem-base'
  | 'guide-stem-robotics'
  | 'guide-stem-battery-transition'
  | 'guide-stem-code-release'
  | 'guide-stem-asset-integrity'
  | 'guide-stem-lab-evidence'
  | 'guide-stem-technical-procurement';

export type ReportWriterType =
  | 'writer-stem-technical-evidence-readiness'
  | 'writer-technical-handover-note'
  | 'writer-gap-request-note';

export type ReadinessStatus =
  | 'DEMO REPORT — NOT AUTHORITY'
  | 'NOT READY — GAPS VISIBLE'
  | 'CONDITIONAL — REVIEW NEEDED'
  | 'BOUNDED REVIEW ONLY';

export interface Job {
  id: JobType;
  name: string;
  description: string;
  icon: string;
}

export interface Guide {
  id: GuideType;
  name: string;
  description: string;
}

export interface ReportWriter {
  id: ReportWriterType;
  name: string;
  description: string;
}

export interface MockReport {
  readinessStatus: ReadinessStatus;
  technicalClaimOrQuestion: string;
  visibleEvidence: string[];
  openGaps: string[];
  burdenConstraintsTiming: string[];
  heldTensions: string[];
  priorityEvidenceMove: string;
  shouldNotYetBeClaimed: string[];
}

export interface AppState {
  currentScreen: 'home' | 'workspace';
  selectedJob: Job | null;
  selectedGuide: Guide | null;
  selectedWriter: ReportWriter | null;
  materialContent: string;
  report: MockReport | null;
  isLoadingReport: boolean;
}
