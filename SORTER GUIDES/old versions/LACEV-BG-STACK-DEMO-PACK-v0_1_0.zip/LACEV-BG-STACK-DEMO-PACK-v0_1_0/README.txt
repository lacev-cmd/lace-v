LACE V / B & G STACK DEMO PACK v0.1.0

WHAT THIS IS
This is a first packaging pass for the LACE V / B & G Stack work.
It is not a final product release. It is a portable demo pack.

The pack shows three things:

1. The umbrella / public-facing demo surface:
   01-LACEV-BG-STACK-OVERVIEW-MERCATOR-DEMO-v2_6_1.html

2. A filled assembled cartridge tool:
   02-ASSEMBLED-REENTRY-MAP-DEMO-v0_1_0.html

3. The generic cartridge shell before assembly:
   03-GENERIC-CARTRIDGE-SHELL-v0_1_0.html

WHAT TO OPEN FIRST
Open 00-START-HERE.html.

FAST TEST
1. Open 02-ASSEMBLED-REENTRY-MAP-DEMO-v0_1_0.html.
2. Click "See a sample".
3. Read the generated map.
4. Notice the pattern:
   generic shell + injected cartridge = bespoke working tool.

WHAT THIS PROVES
The B & G Stack can assemble a domain-specific tool surface from controlled parts.
This is not just a static page. It is a working local HTML tool with a cartridge injected into a generic shell.

WHAT IT DOES NOT PROVE YET
- No customer demand has been proven.
- No pilot has been signed.
- The current demo is not encrypted.
- It is not ready for sensitive real-world distribution.
- It is not therapy, legal advice, diagnosis, risk scoring, parole/compliance monitoring, or surveillance.

DATA / PRIVACY
These demo files run locally in the browser.
The current prototype uses browser local storage.
Do not use with real sensitive material until the PIN/passphrase encryption layer is built.

STATUS
Prototype demo pack.
