# Mercator — Security & Distribution Notes

## Core security requirement
PIN/passphrase protection on all distributed versions before any distribution conversation begins.

- First launch: user creates PIN before anything else loads
- PIN-derived key encrypts all stored data client-side
- No recovery mechanism — irretrievability is the guarantee, not a flaw
- Wrong PIN = nothing readable
- No account, no email, no backdoor

## PIN vs passphrase
- PIN: faster on tablet, easier to use
- Passphrase: harder to shoulder-surf
- Consider per-context: passphrase for prison, PIN acceptable for job agency / consumer

## USB distribution model
- Static HTML + JS, no network dependency, no CDN, no backend
- All data stays on the stick
- Swap localStorage for file-based persistence
- Cost per unit: ~$2

## Distribution channels being considered
- **Prison Fellowship Australia** — pilot, Inside + Reentry cartridges, library or tablet, institution or charity issued
- **Job agencies** — Job Hunt cartridge, given to client as their private tool, not the agency's
- **Consumer web app** — remaining cartridges, free or freemium, low marginal cost

## Trust architecture per context
- Prison: distributed by Prison Fellowship independently, not through corrections system — matters for trust
- Job agency: positioned as client's private tool, agency cannot see it — produces honest signal
- Consumer: PIN + no account = ownable, private, no subscription creep

## The security argument is the product argument
The data stays on the device. No server. No account. Physically incapable of reporting back. That answers every data governance question before it's asked.

## Next steps
- Build PIN/passphrase layer before any distribution conversation
- Solve file-based persistence for USB deployment
- Mobile shell before any pilot approach
